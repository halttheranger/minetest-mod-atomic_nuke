-- DESERT MOD
-- A mod written by halt_ that adds
-- deserts to the minetest game
-- =====================================
-- >> yum/init.lua
-- Some basic deserts
-- =====================================


minetest.register_node("yum:vanilla_icecream", {
	description = "vanilla icecream",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_vanilla_icecream.png"},
	inventory_image = "yum_vanilla_icecream.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(2),
})

minetest.register_node("yum:bowl", {
	description = "bowl",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_bowl.png"},
	inventory_image = "yum_bowl.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=4},
	on_use = minetest.item_eat(0),
})

minetest.register_node("yum:raspberry_icecream", {
	description = "raspberry icecream",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_raspberry_icecream.png"},
	inventory_image = "yum_raspberry_icecream.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(10),
})

minetest.register_node("yum:vanilla_icecream_block", {
	description = "vanilla icecream block",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_vanilla_icecream_block.png"},
	inventory_image = "yum_vanilla_icecream_block.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})

minetest.register_node("yum:raspberry_icecream_block", {
	description = "raspberry icecream block",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_raspberry_icecream_block.png"},
	inventory_image = "yum_raspberry_icecream_block.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(20),
})

minetest.register_node("yum:donut", {
	description = "donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_donut.png"},
	inventory_image = "yum_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:sugar", {
	description = "sugar",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_sugar.png"},
	inventory_image = "yum_sugar.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(0),
})
minetest.register_node("yum:frosted_donut", {
	description = "frosted donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_frosted_donut.png"},
	inventory_image = "yum_frosted_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(5),
})
minetest.register_node("yum:lemon_donut", {
	description = "lemon donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_lemon_donut.png"},
	inventory_image = "yum_lemon_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(6),
})
minetest.register_node("yum:raspberry_donut", {
	description = "raspberry donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_raspberry_donut.png"},
	inventory_image = "yum_raspberry_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(8),
})
minetest.register_node("yum:boston_creme_donut", {
	description = "boston creme donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_boston_creme_donut.png"},
	inventory_image = "yum_boston_creme_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(12),
})
minetest.register_node("yum:chocolate_donut", {
	description = "chocolate donut",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_chocolate_donut.png"},
	inventory_image = "yum_chocolate_donut.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(11),
})
minetest.register_node("yum:chocolate", {
	description = "chocolate",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_chocolate.png"},
	inventory_image = "yum_chocolate.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("yum:hot_chocolate", {
	description = "hot chocolate",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_hot_chocolate.png"},
	inventory_image = "yum_hot_chocolate.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:apple_cyder", {
	description = "apple cyder",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_apple_cyder.png"},
	inventory_image = "yum_apple_cyder.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:apple_juice", {
	description = "apple juice",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_apple_juice.png"},
	inventory_image = "yum_apple_juice.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:raspberry_juice", {
	description = "raspberry juice",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_raspberry_juice.png"},
	inventory_image = "yum_raspberry_juice.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:blueberry_juice", {
	description = "blueberry juice",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_blueberry_juice.png"},
	inventory_image = "yum_blueberry_juice.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:orange_juice", {
	description = "orange juice",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_orange_juice.png"},
	inventory_image = "yum_orange_juice.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:lemonaid", {
	description = "lemonaid",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_lemonaid.png"},
	inventory_image = "yum_lemonaid.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:fruit_punch", {
	description = "fruit punch",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_fruit_punch.png"},
	inventory_image = "yum_fruit_punch.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(4),
})
minetest.register_node("yum:lemon", {
	description = "lemon",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_lemon.png"},
	inventory_image = "yum_lemon.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(1),
})
minetest.register_node("yum:orange", {
	description = "orange",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_orange.png"},
	inventory_image = "yum_orange.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(1),
})
minetest.register_node("yum:wheat", {
	description = "wheat",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_wheat.png"},
	inventory_image = "yum_wheat.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(0),
})
minetest.register_node("yum:glass_cup", {
	description = "glass cup",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"yum_glass_cup.png"},
	inventory_image = "yum_glass_cup.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = minetest.item_eat(0),
})

	minetest.register_craft({
		output = "yum:glass_cup 5",
		recipe = {
			{"default:glass", "", "default:glass"},
			{"default:glass", "", "default:glass"},
			{"", "default:glass", ""},
		},
})

	minetest.register_craft({
		output = "yum:wheat 5",
		recipe = {
			{"", "default:dirt", ""},
			{"default:dirt", "default:sand", "default:dirt"},
			{"", "default:dirt", ""},
		},
})

	minetest.register_craft({
		output = "yum:orange 5",
		recipe = {
			{"", "default:dirt", ""},
			{"default:dirt", "default:dirt", "default:dirt"},
			{"", "default:dirt", ""},
		},
})

	minetest.register_craft({
		output = "yum:lemon 5",
		recipe = {
			{"", "default:sand", ""},
			{"default:sand", "default:dirt", "default:sand"},
			{"", "default:sand", ""},
		},
})


	minetest.register_craft({
		output = "yum:fruit_punch 5",
		recipe = {
			{"yum:sugar", "yum:lemonaid", "yum:sugar"},
			{"yum:raspberry_juice", "yum:orange_juice", "yum:apple_juice"},
			{"yum:sugar", "yum:blueberry_juice", "yum:sugar"},
		},
})

	minetest.register_craft({
		output = "yum:lemonaid 2",
		recipe = {
			{"", "yum:lemon", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:orange_juice 2",
		recipe = {
			{"", "yum:orange", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:blueberry_juice 2",
		recipe = {
			{"", "bushes:blueberry", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:raspberry_juice 2",
		recipe = {
			{"", "bushes:raspberry", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:apple_juice 2",
		recipe = {
			{"", "default:apple", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})
	minetest.register_craft({
		output = "yum:apple_juice 2",
		recipe = {
			{"", "default:apple", ""},
			{"", "vessels:drinking_glass", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:apple_juice 2",
		recipe = {
			{"", "default:apple", ""},
			{"", "vessels:drinking_glass", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:bowl",
		recipe = {
			{"", "default:stick", ""},
			{"default:wood", "", "default:wood"},
			{"", "default:wood", ""},
		},
})

	minetest.register_craft({
		output = "yum:sugar 9",
		recipe = {
			{"default:papyrus", "default:papyrus", "default:papyrus"},
			{"default:papyrus", "default:papyrus", "default:papyrus"},
			{"default:papyrus", "default:papyrus", "default:papyrus"},
		},
})

	minetest.register_craft({
		output = "yum:chocolate",
		recipe = {
			{"", "default:leaves", ""},
			{"default:leaves", "default:leaves", "default:leaves"},
			{"", "default:leaves", ""},
		},
})

	minetest.register_craft({
		output = "yum:chocolate_donut 4",
		recipe = {
			{"", "yum:chocolate", ""},
			{"yum:chocolate", "yum:donut", "yum:chocolate"},
			{"", "yum:chocolate", ""},
		},
})

	minetest.register_craft({
		output = "yum:boston_creme_donut 4",
		recipe = {
			{"", "yum:chocolate", ""},
			{"", "yum:donut", ""},
			{"", "yum:sugar", ""},
		},
})

	minetest.register_craft({
		output = "yum:hot_chocolate",
		recipe = {
			{"", "yum:chocolate", ""},
			{"", "yum:glass_cup", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:hot_chocolate",
		recipe = {
			{"", "yum:chocolate", ""},
			{"", "vessels:drinking_glass", ""},
			{"", "", ""},
		},
})


	minetest.register_craft({
		output = "yum:lemon_donut 4",
		recipe = {
			{"", "yum:lemon", ""},
			{"", "yum:donut", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:raspberry_donut 4",
		recipe = {
			{"", "bushes:raspberry", ""},
			{"", "yum:donut", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:frosted_donut 4",
		recipe = {
			{"", "yum:sugar", ""},
			{"", "yum:donut", ""},
			{"", "", ""},
		},
})

	minetest.register_craft({
		output = "yum:donut 4",
		recipe = {
			{"", "yum:sugar", ""},
			{"yum:sugar", "yum:wheat", "yum:sugar"},
			{"", "yum:sugar", ""},
		},
})

	minetest.register_craft({
		output = "yum:vanilla_icecream 10",
		recipe = {
			{"", "", ""},
			{"", "default:ice", "default:stick"},
			{"", "yum:bowl", ""},
		},
})
	minetest.register_craft({
		output = "yum:raspberry_icecream 2",
		recipe = {
			{"bushes:raspberry", "bushes:raspberry", "bushes:raspberry"},
			{"bushes:raspberry", "yum:vanilla_icecream", "bushes:raspberry"},
			{"bushes:raspberry", "bushes:raspberry", "bushes:raspberry"},
		},
})

	minetest.register_craft({
		output = "yum:vanilla_icecream_block",
		recipe = {
			{"yum:icecream_vanilla", "yum:icecream_vanilla", "yum:icecream_vanilla"},
			{"yum:icecream_vanilla", "yum:icecream_vanilla", "yum:icecream_vanilla"},
			{"yum:icecream_vanilla", "yum:icecream_vanilla", "yum:icecream_vanilla"},
		},
})
	minetest.register_craft({
		output = "yum:icecream_raspberry",
		recipe = {
			{"yum:icecream_raspberry", "yum:icecream_raspberry", "yum:icecream_raspberry"},
			{"yum:icecream_raspberry", "yum:icecream_raspberry", "yum:icecream_raspberry"},
			{"yum:icecream_raspberry", "yum:icecream_raspberry", "yum:icecream_raspberry"},
		},
})
